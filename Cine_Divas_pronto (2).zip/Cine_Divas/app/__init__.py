import os
from flask import Flask
def create_app():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    app = Flask(__name__, template_folder=os.path.join(root, "views"), static_folder=os.path.join(root, "static"), instance_relative_config=True)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "chave-local-cine-divas")
    os.makedirs(app.instance_path, exist_ok=True)
    app.config["DATABASE"] = os.path.join(app.instance_path, "cine_divas.db")
    from app.controllers.auth_controller import auth
    from app.controllers.home_controller import home
    app.register_blueprint(auth)
    app.register_blueprint(home)
    return app
