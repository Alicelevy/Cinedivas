from flask import Blueprint, render_template, request, session
home=Blueprint("home",__name__)
FILMES=[
("Como Perder um Homem em 10 Dias",2003,["Romance","Comédia"],"💛","Andie precisa escrever uma matéria sobre como afastar um homem em dez dias. Benjamin também tem uma aposta, mas os dois acabam se apaixonando de verdade.","É engraçado ver os dois tentando enganar um ao outro."),
("A Culpa é das Estrelas",2014,["Romance","Drama"],"💙","Hazel conhece Augustus em um grupo de apoio. Eles se aproximam e vivem uma história de amor bonita, mesmo passando por momentos difíceis.","É um romance emocionante que faz pensar bastante."),
("Minha Culpa",2023,["Romance","Drama"],"❤️","Noah vai morar com o novo marido da mãe e conhece Nick, seu novo meio-irmão. No começo eles não se dão bem, mas acabam desenvolvendo sentimentos complicados.","Tem romance, conflitos e bastante drama."),
("Legalmente Loira",2001,["Romance","Comédia"],"💗","Elle fica arrasada depois que o namorado termina com ela. Então, entra em Harvard para provar que é muito mais capaz do que ele imagina.","Gosto de como ela mostra que pode conquistar as próprias coisas."),
("Nos Vemos em Vênus",2023,["Romance","Drama"],"🌷","Mia e Kyle viajam pela Espanha e acabam ficando cada vez mais próximos. A viagem muda a forma como eles enxergam a vida e um ao outro.","É uma história romântica e cheia de descobertas."),
("A Cinco Passos de Você",2019,["Romance","Drama"],"💜","Stella e Will se conhecem durante o tratamento no hospital e começam a gostar um do outro. O problema é que precisam manter distância por causa da saúde.","O casal é fofo, mas a história também é triste."),
("10 Coisas que Eu Odeio em Você",1999,["Romance","Comédia"],"🖤","Kat não quer saber de namoro, mas Patrick aparece na vida dela por causa de uma aposta. Aos poucos, o plano acaba virando sentimento de verdade.","É um clássico adolescente com personagens marcantes."),
("O Casamento do Meu Melhor Amigo",1997,["Romance","Comédia"],"💐","Julianne percebe que ama seu melhor amigo quando descobre que ele vai se casar. Ela tenta mudar a situação antes que seja tarde demais.","É interessante ver como ela lida com seus sentimentos."),
("Meu Primeiro Amor",1991,["Romance","Drama"],"🌼","Vada está descobrindo várias coisas sobre crescer. Sua amizade com Thomas J. vira uma história delicada sobre primeiro amor.","É uma história sensível sobre amizade e infância."),
("Operação Cupido",1998,["Comédia","Família"],"🎀","Duas meninas gêmeas se conhecem em um acampamento e descobrem que são irmãs. Elas trocam de lugar para tentar juntar os pais novamente.","É divertido e dá aquela nostalgia de filme antigo.")
]
@home.route("/")
def home_page():
    busca=request.args.get("busca","").strip(); genero=request.args.get("genero","")
    filmes=[{"titulo":t,"ano":a,"generos":g,"icone":i,"descricao":d,"motivo":m,"cor":["pink","blue","red","rose","purple","gold","black","green","yellow","pink"][n]} for n,(t,a,g,i,d,m) in enumerate(FILMES)]
    if busca: filmes=[f for f in filmes if busca.casefold() in f["titulo"].casefold()]
    if genero: filmes=[f for f in filmes if genero in f["generos"]]
    return render_template("home.html",filmes=filmes,generos=["Romance","Comédia","Drama","Família"],busca=busca,genero=genero,usuario=session.get("usuario"))
