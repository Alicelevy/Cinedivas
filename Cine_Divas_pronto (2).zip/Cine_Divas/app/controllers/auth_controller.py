import sqlite3
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from app.db import get_db, init_db, close_db
auth = Blueprint("auth", __name__)
@auth.before_app_request
def setup_db(): init_db()
@auth.teardown_app_request
def cleanup(error=None): close_db(error)
@auth.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if request.method == "POST":
        usuario=request.form.get("usuario","").strip(); senha=request.form.get("senha",""); confirmar=request.form.get("confirmar_senha","")
        if not usuario or not senha or not confirmar: flash("Preencha todos os campos.", "erro")
        elif len(usuario)<3: flash("O usuário precisa ter pelo menos 3 caracteres.", "erro")
        elif len(senha)<6: flash("A senha precisa ter pelo menos 6 caracteres.", "erro")
        elif senha!=confirmar: flash("As senhas não são iguais.", "erro")
        else:
            try:
                get_db().execute("INSERT INTO usuarios (usuario, senha_hash) VALUES (?,?)",(usuario,generate_password_hash(senha))); get_db().commit()
                flash("Conta criada! Agora faça login 💗","sucesso"); return redirect(url_for("auth.login"))
            except sqlite3.IntegrityError: flash("Esse usuário já existe.", "erro")
    return render_template("cadastro.html")
@auth.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        usuario=request.form.get("usuario","").strip(); senha=request.form.get("senha","")
        u=get_db().execute("SELECT * FROM usuarios WHERE usuario=?",(usuario,)).fetchone()
        if u and check_password_hash(u["senha_hash"],senha):
            session.clear(); session["usuario"]=u["usuario"]; return redirect(url_for("home.home_page"))
        flash("Usuário ou senha incorretos.", "erro")
    return render_template("login.html")
@auth.route("/logout")
def logout():
    session.clear(); return redirect(url_for("auth.login"))
