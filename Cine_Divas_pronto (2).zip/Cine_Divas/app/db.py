import sqlite3
from flask import current_app, g
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db
def init_db():
    get_db().execute("CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, usuario TEXT UNIQUE NOT NULL, senha_hash TEXT NOT NULL)")
    get_db().commit()
def close_db(error=None):
    db = g.pop("db", None)
    if db is not None: db.close()
